package com.isaplings.travelfriend;

public class DistanceUnit {
    static String[] code = new String[]{
        "km",
        "mi"
    };
}